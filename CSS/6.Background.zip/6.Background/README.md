https://cssgradient.io/

https://webgradients.com/

https://uigradients.com/#Mini

https://unsplash.com/es

https://boxicons.com/

https://www.toptal.com/designers/subtlepatterns/